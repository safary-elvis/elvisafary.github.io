# Elvis Ariga Safary — personal portfolio

A lightweight, responsive, multi-page static website inspired by the clean editorial layout of the reference site.

## Files

- `index.html` — Home page and profile
- `writing.html` — Writing and publications
- `activism.html` — Advocacy and rights-based work
- `filmmaking.html` — Film and visual storytelling portfolio
- `other.html` — Additional work, methods and interests
- `styles.css` — Shared layout, typography and colour theme
- `config.js` — Contact email configuration
- `script.js` — Mobile navigation and shared page details
- `assets/` — Portrait and CV files

## Before publishing

1. **Add your portrait:** place your preferred headshot in `assets/` and name it `profile-photo.jpg`. The image is displayed centrally on the home page. If the file is absent, a neutral placeholder appears.
2. **Add your CV:** place your PDF in `assets/` and name it `Elvis-Safary-CV.pdf`. The Download CV link in the top-right navigation on every page points to this file. The CV itself was not included in the supplied upload.
3. **Set your email:** open `config.js` and replace `YOUR_EMAIL@example.com` with the email address you want displayed and linked.
4. **Review page content:** add verified publication links, advocacy examples and film credits. The pages intentionally use thematic introductory copy where project-specific details were not supplied.

## Run locally

Open `index.html` in a browser. No build tools, package installation or server-side code are required.

## Publish with GitHub Pages

1. Create or open your GitHub repository.
2. Upload all files and folders in this project, preserving the folder structure.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder, then save.
6. Wait for GitHub Pages to publish the site. The public URL will appear in the Pages settings.

Use `index.html` as the repository's root entry page. Keep the HTML files, `styles.css`, `config.js`, `script.js` and `assets/` together.

## Design notes

The design uses a white background, charcoal typography, fine grey rules, a restrained serif display face and a sans-serif body face. The navigation is clickable across separate pages, collapses to a mobile menu on smaller screens, and includes the CV link on the far right on desktop.
