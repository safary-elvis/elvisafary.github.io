/*
  PERSONALISE THESE SETTINGS BEFORE PUBLISHING.
  Replace the email below with the email address you want visitors to use.
*/
window.PORTFOLIO_CONFIG = {
  email: "YOUR_EMAIL@example.com"
};
